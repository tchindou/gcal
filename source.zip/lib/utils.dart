import 'dart:ui';


class Apps {
  static const Color PrimaryColor = Color(0xFFF1F1F1);
  static const Color SecondaryColor = Color(0xFFE5E5E5);
  static const Color BackgroundColor = Color(0xFFFAFAFA);
  static const Color HCardColor = Color(0xFFFFFFFF);
}
